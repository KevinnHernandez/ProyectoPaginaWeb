This template / effect / code has been created by Amber Martineau.
You can customize and check it out on its original site on the following link:
https://codepen.io/ambermdesign/pen/YzPgOvy

Thank you